import express from 'express';
import axios from 'axios';
import path from 'path';
import { fileURLToPath } from 'url';

// Estas dos líneas son necesarias para obtener __dirname en ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

//configuración del puerto
const app = express();
const PORT = 3001;

// Servir archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/cards', async (req, res) => {
    try {
        const response = await axios.get('https://db.ygoprodeck.com/api/v7/cardinfo.php');
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener los datos' });
    }
});

app.get('/cards/name/:name', async (req, res) => {
    const { name } = req.params;
    try {
        const response = await axios.get(`https://db.ygoprodeck.com/api/v7/cardinfo.php?name=${name}`);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener los datos' });
    }
});

app.get('/cards/type/:type', async (req, res) => {
    const { type } = req.params;
    try {
        const response = await axios.get(`https://db.ygoprodeck.com/api/v7/cardinfo.php?type=${type}`);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener los datos' });
    }
});

app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
